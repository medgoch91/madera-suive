-- ================================================================
--  سويفي — Supabase Database Schema
--  توليد تلقائي من index_26.html
-- ================================================================

-- ╔══════════════════════════════╗
-- ║  1. FOURNISSEURS             ║
-- ╚══════════════════════════════╝
create table if not exists fournisseurs (
  id          bigint generated always as identity primary key,
  nom         text        not null,
  tel         text        default '',
  ville       text        default '',
  email       text        default '',
  cat         text        default 'مورد',
  stat        text        default 'نشيط',
  notes       text        default '',
  created_at  timestamptz default now()
);

-- ╔══════════════════════════════╗
-- ║  2. ARTICLES                 ║
-- ╚══════════════════════════════╝
create table if not exists articles (
  id    bigint generated always as identity primary key,
  nom   text not null,
  unite text default '',
  cat   text default '',
  ref   text default ''
);

-- ╔══════════════════════════════╗
-- ║  3. PRIX                     ║
-- ╚══════════════════════════════╝
create table if not exists prix (
  id          bigint generated always as identity primary key,
  article_id  bigint references articles(id) on delete cascade,
  fournisseur text   not null,
  prix        numeric(12,2) default 0,
  unique (article_id, fournisseur)
);

-- ╔══════════════════════════════╗
-- ║  4. BONS                     ║
-- ╚══════════════════════════════╝
create table if not exists bons (
  id          bigint generated always as identity primary key,
  num         int           default 0,
  fournisseur text          not null,
  date        date,
  note        text          default '',
  statut      text          default 'Brouillon',
  remise_type text          default '%',
  remise_val  numeric(10,2) default 0,
  total       numeric(12,2) default 0,
  total_net   numeric(12,2) default 0,
  cheque_id   bigint        default null,
  lignes      jsonb         default '[]',
  created_at  timestamptz   default now()
);

-- ╔══════════════════════════════╗
-- ║  5. CHEQUES                  ║
-- ╚══════════════════════════════╝
create table if not exists cheques (
  id          bigint generated always as identity primary key,
  num         int           default 0,
  fournisseur text          not null,
  montant     numeric(12,2) default 0,
  date        date,
  echeance    date          default null,
  status      text          default 'معلق',
  bon_ids     jsonb         default '[]',
  created_at  timestamptz   default now()
);

-- ╔══════════════════════════════╗
-- ║  6. SALARIES                 ║
-- ╚══════════════════════════════╝
create table if not exists salaries (
  id           bigint generated always as identity primary key,
  nom          text          not null,
  prenom       text          default '',
  poste        text          default '',
  tel          text          default '',
  cin          text          default '',
  salaire_base numeric(10,2) default 0,
  taux_hsup    numeric(6,2)  default 0,
  actif        boolean       default true,
  notes        text          default '',
  created_at   timestamptz   default now()
);

-- ╔══════════════════════════════╗
-- ║  7. SALARIE_PRESENCES        ║
-- ╚══════════════════════════════╝
create table if not exists salarie_presences (
  id           bigint generated always as identity primary key,
  salarie_id   bigint references salaries(id) on delete cascade,
  date         date not null,
  statut       text          default 'present',   -- present / absent / conge / demi
  heures_supp  numeric(6,2)  default 0,
  taux_horaire numeric(8,2)  default 0,
  notes        text          default '',
  unique (salarie_id, date)
);

-- ╔══════════════════════════════╗
-- ║  8. SALARIE_AVANCES          ║
-- ╚══════════════════════════════╝
create table if not exists salarie_avances (
  id         bigint generated always as identity primary key,
  salarie_id bigint references salaries(id) on delete cascade,
  montant    numeric(10,2) default 0,
  date       date,
  notes      text          default '',
  rembourse  boolean       default false,
  created_at timestamptz   default now()
);

-- ╔══════════════════════════════╗
-- ║  9. SALARIE_TASWIYAS         ║
-- ╚══════════════════════════════╝
create table if not exists salarie_taswiyas (
  id             bigint generated always as identity primary key,
  salarie_id     bigint references salaries(id) on delete cascade,
  nom_salarie    text          default '',
  montant        numeric(10,2) default 0,
  date_from      date,
  date_to        date,
  date_paiement  date,
  created_at     timestamptz   default now()
);

-- ╔══════════════════════════════╗
-- ║  10. SAL_CATALOGUE           ║
-- ╚══════════════════════════════╝
create table if not exists sal_catalogue (
  id    bigint generated always as identity primary key,
  nom   text          not null,
  unite text          default 'قطعة',
  prix  numeric(10,2) default 0
);

-- ╔══════════════════════════════╗
-- ║  11. OUVRIERS_PC             ║
-- ╚══════════════════════════════╝
create table if not exists ouvriers_pc (
  id    bigint generated always as identity primary key,
  nom   text    not null,
  actif boolean default true
);

-- ╔══════════════════════════════╗
-- ║  12. OUVRIER_PC_ASSIGN       ║
-- ╚══════════════════════════════╝
create table if not exists ouvrier_pc_assign (
  id         bigint generated always as identity primary key,
  ouvrier_id bigint references ouvriers_pc(id) on delete cascade,
  pc_nom     text          not null,
  prix       numeric(10,2) default 0
);

-- ╔══════════════════════════════╗
-- ║  13. OUVRIER_PC_PRESENCES    ║
-- ╚══════════════════════════════╝
create table if not exists ouvrier_pc_presences (
  id         bigint generated always as identity primary key,
  ouvrier_id bigint references ouvriers_pc(id) on delete cascade,
  date       date   not null,
  pc_nom     text   not null,
  qte        numeric(10,2) default 0,
  prix       numeric(10,2) default 0,
  unique (ouvrier_id, date, pc_nom)
);

-- ╔══════════════════════════════╗
-- ║  14. FACT_CLIENTS            ║
-- ╚══════════════════════════════╝
create table if not exists fact_clients (
  id      bigint generated always as identity primary key,
  nom     text   not null,
  ville   text   default '',
  ice     text   default '',
  tel     text   default '',
  adresse text   default ''
);

-- ╔══════════════════════════════╗
-- ║  15. FACT_PRODUITS           ║
-- ╚══════════════════════════════╝
create table if not exists fact_produits (
  id    bigint generated always as identity primary key,
  nom   text          not null,
  ref   text          default '',
  prix  numeric(10,2) default 0,
  tva   numeric(5,2)  default 20,
  unite text          default 'Pce'
);

-- ╔══════════════════════════════╗
-- ║  16. FACT_SOCIETE            ║
-- ╚══════════════════════════════╝
create table if not exists fact_societe (
  id      bigint generated always as identity primary key,
  nom     text   default '',
  ice     text   default '',
  if_num  text   default '',
  rc      text   default '',
  patente text   default '',
  ville   text   default '',
  tel     text   default '',
  fax     text   default '',
  email   text   default '',
  web     text   default '',
  adresse text   default '',
  logo    text   default ''   -- base64 image
);

-- ╔══════════════════════════════╗
-- ║  17. FACTURES                ║
-- ╚══════════════════════════════╝
create table if not exists factures (
  id           bigint generated always as identity primary key,
  num          int           default 0,
  client_id    bigint        default null references fact_clients(id) on delete set null,
  client_nom   text          default '',
  client_ville text          default '',
  client_ice   text          default '',
  date         date,
  echeance     date          default null,
  lang         text          default 'ar',
  mode         text          default 'espèces',
  lignes       jsonb         default '[]',
  total_ht     numeric(12,2) default 0,
  total_tva    numeric(12,2) default 0,
  total_ttc    numeric(12,2) default 0,
  statut       text          default 'معلقة',
  notes        text          default '',
  created_at   timestamptz   default now()
);

-- ================================================================
--  RLS — Disable for anon key (single-user app)
--  or enable below and add policies as needed
-- ================================================================
alter table fournisseurs          enable row level security;
alter table articles              enable row level security;
alter table prix                  enable row level security;
alter table bons                  enable row level security;
alter table cheques               enable row level security;
alter table salaries              enable row level security;
alter table salarie_presences     enable row level security;
alter table salarie_avances       enable row level security;
alter table salarie_taswiyas      enable row level security;
alter table sal_catalogue         enable row level security;
alter table ouvriers_pc           enable row level security;
alter table ouvrier_pc_assign     enable row level security;
alter table ouvrier_pc_presences  enable row level security;
alter table fact_clients          enable row level security;
alter table fact_produits         enable row level security;
alter table fact_societe          enable row level security;
alter table factures              enable row level security;

-- Allow anon full access (since app handles auth locally)
do $$
declare t text;
begin
  foreach t in array array[
    'fournisseurs','articles','prix','bons','cheques',
    'salaries','salarie_presences','salarie_avances','salarie_taswiyas','sal_catalogue',
    'ouvriers_pc','ouvrier_pc_assign','ouvrier_pc_presences',
    'fact_clients','fact_produits','fact_societe','factures'
  ] loop
    execute format('create policy "anon_all_%s" on %I for all to anon using (true) with check (true)', t, t);
  end loop;
end $$;
